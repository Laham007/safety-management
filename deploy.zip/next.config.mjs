/** @type {import('next').NextConfig} */
const nextConfig = {
  // Disable ESLint during build
  eslint: {
    ignoreDuringBuilds: true,
  },
  
  // Disable TypeScript type checking during build
  typescript: {
    ignoreBuildErrors: true,
  },
  
  // Image optimization
  images: {
    domains: ['localhost'],
    unoptimized: true, // Disable image optimization for Netlify
  },
  
  // Enable React strict mode
  reactStrictMode: true,
  
  // Enable SWC minification
  swcMinify: true,
  
  // Disable powered-by header
  poweredByHeader: false,
  
  // Performance optimizations
  compress: true,
  
  // Disable source maps in production
  productionBrowserSourceMaps: false,
  
  // Enable trailing slashes for all URLs
  trailingSlash: true,
  
  // Configure headers
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'X-Frame-Options',
            value: 'DENY',
          },
          {
            key: 'X-XSS-Protection',
            value: '1; mode=block',
          },
        ],
      },
    ];
  },
  
  // Webpack configuration
  webpack: (config, { isServer }) => {
    if (!isServer) {
      config.resolve.fallback = {
        ...config.resolve.fallback,
        fs: false,
        net: false,
        tls: false,
      };
    }
    return config;
  },
};

// For Netlify deployment
nextConfig.output = 'export';
nextConfig.basePath = '';
nextConfig.assetPrefix = '';
nextConfig.images.unoptimized = true;

// Disable image optimization in export
if (process.env.NETLIFY === 'true') {
  nextConfig.images.loader = 'imgix';
  nextConfig.images.path = '/';
}

export default nextConfig;
